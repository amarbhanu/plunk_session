const MY_DOMAIN ='localhost' ;
const MY_PORT ='80' ;
const MY_MASTER='AMAR KUMAR BHANU';
