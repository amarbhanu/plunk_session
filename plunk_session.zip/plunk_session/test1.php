<?php

 $array = array("username"=>"John Smith","id"=>10, "permission"=>array("one"=>"normal","two"=>"nice","three"=>"hmm","3"=>"ok"));
echo json_encode($array);
?>